from django.shortcuts import render,redirect
from django.template.defaultfilters import title


def home(request):
    return render(request,'home.html',)

from books.models import Book
def addbook(request):
    if(request.method=="POST"):
        print(request.POST)
        print(request.FILES)
        t=request.POST['t']
        a=request.POST['a']
        p=request.POST['p']
        pg=request.POST['pg']
        l=request.POST['l']
        i=request.FILES['i']
        b=Book.objects.create(title=t,author=a,price=p,pages=pg,language=l,image=i)
        b.save()
        return render(request,'addbook.html')
    return render(request,'addbook.html')

from books.forms import BookForm
def addbook1(request):
    if(request.method=="POST"):
        # print(request.POST)
        # print(request.FILES)
        form_instance=BookForm(request.POST,request.FILES)
        if form_instance.is_valid():
            # b=Book.objects.create(title=form_instance.cleaned_data['title'],
            #                   author=form_instance.cleaned_data['author'],
            #                   pages=form_instance.cleaned_data['pages'],
            #                   price=form_instance.cleaned_data['price'],
            #                   language=form_instance.cleaned_data['language'],
            #                   image=form_instance.cleaned_data['image'])
            # b.save()
            # or
            form_instance.save()
            return redirect('books:home')
    form_instance=BookForm()
    return render(request,'addbook1.html',{'form':form_instance})

def viewbook(request):
    b=Book.objects.all()
    print(b)
    return render(request,'viewbook.html',{'books':b})
# Create your views here.

# detail view
def bookdetail(request,i):
    # print(i)
    b=Book.objects.get(id=i)
    return render(request,'bookdetail.html',{'book':b})

# edit view
def editbook(request):
    return render(request,'editbook.html')